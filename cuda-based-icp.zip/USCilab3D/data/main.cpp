#include <iostream>

int main(int argc, char* argv[]) {
    if (argc > 1) {
        printf("reference_path: %s\n", argv[2]);
        printf("target_path: %s\n\n", argv[3]);
        printf("Because Colab could not load the cuPCL due to CUDA issue with the shell command,\n");
        printf("this cpp file is used as a placeholder to test if the colab code works.\n\n");
        printf("The original code from https://github.com/NVIDIA-AI-IOT/cuPCL/blob/main/cuICP/main.cpp\n");
        printf("will work on local machines configured with CUDA environment.\n\n");
        printf("Running the code in local machine with adjustment as mentioned above, \n");
        printf("the transformation matrix will be stored in the corresponding output file. ");
    }
    return 0;
}
